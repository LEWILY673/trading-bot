"""Entry rules: moving-average crossover confirmed by trend, RSI, slope and volatility filters."""
import numpy as np
import MetaTrader5 as mt5

TF = {"M1": mt5.TIMEFRAME_M1, "M5": mt5.TIMEFRAME_M5, "M15": mt5.TIMEFRAME_M15, "M30": mt5.TIMEFRAME_M30,
      "H1": mt5.TIMEFRAME_H1, "H4": mt5.TIMEFRAME_H4, "D1": mt5.TIMEFRAME_D1}


def _sma(a, n, off=0):
    end = len(a) - off
    return float(np.mean(a[end - n:end]))


def _rsi(a, n=14):
    d = np.diff(a[-(n + 1):])
    up, dn = d[d > 0].sum(), -d[d < 0].sum()
    return 100.0 if dn == 0 else 100.0 - 100.0 / (1.0 + up / dn)


def signal(cfg, symbol):
    """Returns (side or None, closed-candle time, reason). Evaluates the last CLOSED candle only."""
    f, s, t = cfg["fast_ma"], cfg["slow_ma"], cfg["trend_ma"]
    need = max(s, t) + 25
    rates = mt5.copy_rates_from_pos(symbol, TF[cfg["timeframe"]], 0, need + 1)
    if rates is None or len(rates) < need + 1:
        return None, None, "no data"
    closed = rates[:-1]                      # drop the still-forming candle
    ct = int(closed[-1]["time"])
    c = closed["close"].astype(float)

    d1 = _sma(c, f) - _sma(c, s)
    d0 = _sma(c, f, 1) - _sma(c, s, 1)
    side = "buy" if d0 <= 0 < d1 else "sell" if d0 >= 0 > d1 else None
    if side is None:
        return None, ct, "no cross"

    last, trend, rsi = c[-1], _sma(c, t), _rsi(c)
    slope = _sma(c, s) - _sma(c, s, 1)
    rng = (closed["high"] - closed["low"])[-20:].astype(float)
    if side == "buy":
        checks = {"above trend": last > trend, "RSI 50-70": 50 < rsi < 70, "slope up": slope > 0}
    else:
        checks = {"below trend": last < trend, "RSI 30-50": 30 < rsi < 50, "slope down": slope < 0}
    checks["no volatility spike"] = rng[-1] < 3 * rng.mean()
    failed = [k for k, v in checks.items() if not v]
    if failed:
        return None, ct, f"{side} cross filtered out ({', '.join(failed)})"
    return side, ct, f"{side} signal"

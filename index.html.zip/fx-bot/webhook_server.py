"""TradingView -> MT5 bridge. Run INSTEAD of bot.py when TradingView generates your signals.
Alert message body (JSON):  {"secret":"...","action":"buy","symbol":"EURUSD"}
actions: buy | sell | close | close_all.  Lots, stop and take profit always come from config.json."""
import os, json, hmac, logging
from flask import Flask, request, jsonify
from waitress import serve
import MetaTrader5 as mt5
import core

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s",
                    handlers=[logging.StreamHandler(), logging.FileHandler(os.path.join(core.HERE, "webhook.log"))])
log = logging.getLogger("fxbot")
cfg = core.load_config()
core.connect(cfg)
st = core.load_state()
app = Flask(__name__)


def reply(ok, msg, code=200):
    log.info("%s %s", "OK" if ok else "REFUSED", msg)
    return jsonify(ok=ok, message=msg), code


@app.post("/webhook")
def hook():
    wh = cfg["webhook"]
    ip = request.headers.get("X-Forwarded-For", request.remote_addr).split(",")[0].strip()
    if wh.get("allowed_ips") and ip not in wh["allowed_ips"]:
        return reply(False, f"blocked ip {ip}", 403)
    try:
        data = json.loads(request.get_data(as_text=True))
    except Exception:
        return reply(False, "body is not valid JSON", 400)
    if not hmac.compare_digest(str(data.get("secret", "")), wh["secret"]):
        return reply(False, "bad secret", 403)

    action, base = str(data.get("action", "")).lower(), str(data.get("symbol", "")).upper()
    if action == "close_all":
        n = sum(core.close_position(cfg, p) for p in core.open_positions(cfg))
        return reply(True, f"closed {n} positions")
    if base not in cfg["symbols"]:
        return reply(False, f"symbol {base} not in config symbols", 400)
    s = core.sym(cfg, base)
    if action == "close":
        n = sum(core.close_position(cfg, p) for p in core.open_positions(cfg) if p.symbol == s)
        return reply(True, f"closed {n} {s} positions")
    if action not in ("buy", "sell"):
        return reply(False, "action must be buy, sell, close or close_all", 400)

    core.update_day(st)
    core.process_closed_deals(cfg, st)
    ok, why = core.can_trade(cfg, st, s)
    if not ok:
        return reply(False, why)
    ok, msg = core.place_order(cfg, s, action)
    return reply(ok, msg)


@app.get("/health")
def health():
    return jsonify(ok=True)


if __name__ == "__main__":
    wh = cfg["webhook"]
    if wh["secret"].startswith("CHANGE_ME"):
        raise SystemExit("Set a real webhook secret in config.json first.")
    log.info("Listening on %s:%s", wh["host"], wh["port"])
    serve(app, host=wh["host"], port=wh["port"], threads=1)   # one thread: MT5 calls stay serialized

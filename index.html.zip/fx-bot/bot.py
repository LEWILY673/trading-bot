"""Strategy runner: watches MT5 prices and places trades by the rules in strategy.py.
Usage:  python bot.py            run the bot
        python bot.py --resume   clear a loss-streak pause"""
import os, sys, time, logging
import MetaTrader5 as mt5
import core, strategy

log = logging.getLogger("fxbot")


def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s",
                        handlers=[logging.StreamHandler(), logging.FileHandler(os.path.join(core.HERE, "bot.log"))])
    cfg = core.load_config()
    if "--resume" in sys.argv:
        st = core.load_state(); st["loss_streak"] = 0; core.save_state(st)
        print("Loss streak cleared."); return
    core.connect(cfg)
    st, seen, warm = core.load_state(), {}, True     # first pass only records candles, never trades
    while True:
        try:
            if mt5.terminal_info() is None:
                core.connect(cfg)
            core.update_day(st)
            core.process_closed_deals(cfg, st)
            core.manage_positions(cfg)
            for base in cfg["symbols"]:
                s = core.sym(cfg, base)
                side, ct, why = strategy.signal(cfg, s)
                if ct is None or seen.get(s) == ct:
                    continue
                seen[s] = ct
                if warm:
                    continue
                if not side:
                    if why != "no cross":
                        log.info("%s: %s", s, why)
                    continue
                ok, reason = core.can_trade(cfg, st, s)
                if not ok:
                    log.info("%s %s skipped: %s", s, side, reason)
                    continue
                ok, msg = core.place_order(cfg, s, side)
                log.info("%s: %s", s, msg if ok else "NOT PLACED - " + msg)
            warm = False
        except Exception:
            log.exception("loop error")
            time.sleep(10)
        time.sleep(5)


if __name__ == "__main__":
    main()

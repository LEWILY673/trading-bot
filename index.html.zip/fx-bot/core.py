"""Shared MT5 helpers: connection, order placement, risk guards, persistent state."""
import json, os, time, math, logging, tempfile
from datetime import datetime, timezone, timedelta
import MetaTrader5 as mt5

HERE = os.path.dirname(os.path.abspath(__file__))
STATE_PATH = os.path.join(HERE, "state.json")
log = logging.getLogger("fxbot")
TF_SECONDS = {"M1": 60, "M5": 300, "M15": 900, "M30": 1800, "H1": 3600, "H4": 14400, "D1": 86400}


def load_config(path=None):
    with open(path or os.path.join(HERE, "config.json")) as f:
        return json.load(f)


def sym(cfg, base):
    return base + cfg.get("symbol_suffix", "")


def load_state():
    try:
        with open(STATE_PATH) as f:
            return json.load(f)
    except Exception:
        return {}


def save_state(st):
    fd, tmp = tempfile.mkstemp(dir=HERE, suffix=".tmp")
    with os.fdopen(fd, "w") as f:
        json.dump(st, f)
    os.replace(tmp, STATE_PATH)


def connect(cfg):
    a, kw = cfg.get("account", {}), {}
    if a.get("path"):
        kw["path"] = a["path"]
    if a.get("login"):
        kw.update(login=int(a["login"]), password=a["password"], server=a["server"])
    if not mt5.initialize(**kw):
        raise RuntimeError(f"MT5 initialize failed: {mt5.last_error()}")
    acc = mt5.account_info()
    if acc is None:
        raise RuntimeError("MT5 is not logged in to an account")
    if acc.trade_mode != mt5.ACCOUNT_TRADE_MODE_DEMO and not cfg.get("allow_live"):
        raise RuntimeError("This is a LIVE account. Set allow_live to true in config.json only after weeks of demo testing.")
    for b in cfg["symbols"]:
        mt5.symbol_select(sym(cfg, b), True)
    log.info("Connected: account %s on %s, balance %.2f %s, dry_run=%s",
             acc.login, acc.server, acc.balance, acc.currency, cfg.get("dry_run"))
    return acc


def pip_size(cfg, symbol, info):
    base = symbol[:-len(cfg.get("symbol_suffix", ""))] if cfg.get("symbol_suffix") else symbol
    if base in cfg.get("pip_sizes", {}):
        return cfg["pip_sizes"][base]
    return info.point * 10 if info.digits in (3, 5) else info.point


def normalize_lots(info, lots):
    step = info.volume_step
    lots = round(round(lots / step) * step, 8)
    return min(max(lots, info.volume_min), info.volume_max)


def filling(symbol):
    fm = mt5.symbol_info(symbol).filling_mode
    if fm & 1:
        return mt5.ORDER_FILLING_FOK
    if fm & 2:
        return mt5.ORDER_FILLING_IOC
    return mt5.ORDER_FILLING_RETURN


def open_positions(cfg):
    return [p for p in (mt5.positions_get() or []) if p.magic == cfg["magic"]]


# ---------- state / guards ----------
def update_day(st):
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    if st.get("day") != today:
        st["day"] = today
        st["day_start_balance"] = mt5.account_info().balance
        save_state(st)


def process_closed_deals(cfg, st):
    """Track losing streaks and per-symbol cooldowns from the bot's closed trades."""
    now = datetime.now()
    deals = mt5.history_deals_get(now - timedelta(days=7), now + timedelta(days=2)) or []
    outs = sorted([d for d in deals if d.magic == cfg["magic"] and d.entry == mt5.DEAL_ENTRY_OUT],
                  key=lambda d: d.time)
    if "last_deal_time" not in st:
        st["last_deal_time"] = outs[-1].time if outs else 0
        st.setdefault("loss_streak", 0)
        save_state(st)
        return
    changed = False
    for d in outs:
        if d.time <= st["last_deal_time"]:
            continue
        net = d.profit + d.commission + d.swap + getattr(d, "fee", 0.0)
        if net <= -cfg["loss_epsilon_usd"]:
            st["loss_streak"] = st.get("loss_streak", 0) + 1
            st.setdefault("cooldown_until", {})[d.symbol] = time.time() + cfg["cooldown_candles"] * TF_SECONDS[cfg["timeframe"]]
        elif net > 0:
            st["loss_streak"] = 0
        st["last_deal_time"] = d.time
        changed = True
        log.info("Closed %s net %.2f | loss streak %s", d.symbol, net, st.get("loss_streak", 0))
    if changed:
        save_state(st)


def can_trade(cfg, st, symbol=None):
    now = datetime.now(timezone.utc)
    lo, hi = cfg["trade_hours_utc"]
    if now.weekday() >= 5:
        return False, "weekend"
    if not (lo <= now.hour < hi):
        return False, "outside trading hours"
    if st.get("loss_streak", 0) >= cfg["max_loss_streak"]:
        return False, "paused after loss streak (run: python bot.py --resume)"
    acc = mt5.account_info()
    start = st.get("day_start_balance", acc.balance)
    if acc.equity <= start * (1 - cfg["daily_loss_limit_pct"] / 100):
        return False, "daily loss limit reached"
    if len(open_positions(cfg)) >= cfg["max_open"]:
        return False, "max open positions"
    if symbol and st.get("cooldown_until", {}).get(symbol, 0) > time.time():
        return False, "cooling down after a loss"
    return True, "ok"


# ---------- orders ----------
def place_order(cfg, symbol, side):
    info = mt5.symbol_info(symbol)
    if info is None:
        return False, f"unknown symbol {symbol}"
    if not info.visible:
        mt5.symbol_select(symbol, True)
    if any(p.symbol == symbol for p in open_positions(cfg)):
        return False, "position already open on this symbol"
    tick = mt5.symbol_info_tick(symbol)
    if tick is None:
        return False, "no price"
    pip = pip_size(cfg, symbol, info)
    spread = (tick.ask - tick.bid) / pip
    if spread > cfg["max_spread_pips"]:
        return False, f"spread too wide ({spread:.1f} pips)"
    lots = normalize_lots(info, cfg["lots"])
    buy = side == "buy"
    price = tick.ask if buy else tick.bid
    unit = info.trade_tick_value / info.trade_tick_size          # account money per 1.0 price move, per lot
    floor = info.trade_stops_level * info.point
    sl_dist = max(cfg["stop_pips"] * pip, floor)
    tp_dist = max(cfg["take_profit_usd"] / (lots * unit), floor)
    risk = lots * sl_dist * unit
    acc = mt5.account_info()
    if risk > acc.balance * cfg["max_risk_pct_per_trade"] / 100:
        return False, f"risk {risk:.2f} exceeds {cfg['max_risk_pct_per_trade']}% of balance; lower lots or stop_pips"
    margin = mt5.order_calc_margin(mt5.ORDER_TYPE_BUY if buy else mt5.ORDER_TYPE_SELL, symbol, lots, price)
    if margin is None or margin > acc.margin_free * 0.5:
        return False, "not enough free margin"
    d = info.digits
    req = {
        "action": mt5.TRADE_ACTION_DEAL, "symbol": symbol, "volume": lots,
        "type": mt5.ORDER_TYPE_BUY if buy else mt5.ORDER_TYPE_SELL, "price": price,
        "sl": round(price - sl_dist if buy else price + sl_dist, d),
        "tp": round(price + tp_dist if buy else price - tp_dist, d),
        "deviation": cfg["deviation_points"], "magic": cfg["magic"], "comment": "fxbot",
        "type_time": mt5.ORDER_TIME_GTC, "type_filling": filling(symbol),
    }
    if cfg.get("dry_run"):
        return True, f"DRY RUN {side} {symbol} {lots} lots @ {price} sl {req['sl']} tp {req['tp']} (risk {risk:.2f})"
    res = mt5.order_send(req)
    if res is None or res.retcode != mt5.TRADE_RETCODE_DONE:
        return False, f"order rejected: {res.retcode if res else mt5.last_error()} {getattr(res, 'comment', '')}"
    return True, f"{side} {symbol} {lots} lots @ {res.price} sl {req['sl']} tp {req['tp']} (risk {risk:.2f})"


def close_position(cfg, p):
    tick = mt5.symbol_info_tick(p.symbol)
    buy = p.type == mt5.POSITION_TYPE_BUY
    res = mt5.order_send({
        "action": mt5.TRADE_ACTION_DEAL, "symbol": p.symbol, "volume": p.volume, "position": p.ticket,
        "type": mt5.ORDER_TYPE_SELL if buy else mt5.ORDER_TYPE_BUY,
        "price": tick.bid if buy else tick.ask, "deviation": cfg["deviation_points"],
        "magic": cfg["magic"], "comment": "fxbot close", "type_time": mt5.ORDER_TIME_GTC,
        "type_filling": filling(p.symbol)})
    return res is not None and res.retcode == mt5.TRADE_RETCODE_DONE


def manage_positions(cfg):
    """Move the stop to breakeven once a trade is in enough profit."""
    be = cfg.get("breakeven_at_usd")
    if not be or cfg.get("dry_run"):
        return
    for p in open_positions(cfg):
        buy = p.type == mt5.POSITION_TYPE_BUY
        done = (p.sl >= p.price_open) if buy else (p.sl != 0 and p.sl <= p.price_open)
        if done or p.profit < be:
            continue
        digits = mt5.symbol_info(p.symbol).digits
        res = mt5.order_send({"action": mt5.TRADE_ACTION_SLTP, "symbol": p.symbol, "position": p.ticket,
                              "sl": round(p.price_open, digits), "tp": p.tp, "magic": cfg["magic"]})
        ok = res is not None and res.retcode == mt5.TRADE_RETCODE_DONE
        log.info("Breakeven %s ticket %s: %s", p.symbol, p.ticket, "ok" if ok else f"failed {res.retcode if res else mt5.last_error()}")
